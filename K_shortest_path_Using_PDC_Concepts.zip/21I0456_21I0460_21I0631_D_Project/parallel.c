#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include <omp.h>
#include <mpi.h>

#define INF INT_MAX

struct Node {
    int dest;
    int weight;
    struct Node* next;
};

struct List {
    struct Node* head;
};

struct Path {
    int cost;
    struct Path* next;
};

void addEdge(struct List* array, int src, int dest, int weight) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->dest = dest;
    newNode->weight = weight;
    newNode->next = NULL;

    if (array[src].head == NULL) {
        array[src].head = newNode;
    } else {
        newNode->next = array[src].head;
        array[src].head = newNode;
    }
}

struct Path* findKShortest(struct List* array, int n, int src, int dest, int k, double *exec_time) {
    struct Path* paths[k];
    struct Path* result = NULL;
    struct Path* currentPath;

    for (int i = 0; i < k; i++) {
        paths[i] = NULL;
    }

    int *dis = (int *)malloc((n + 1) * sizeof(int));
    for (int i = 0; i <= n; i++) {
        dis[i] = INF;
    }

    struct Pair {
        int vertex;
        int distance;
    };
    struct Pair *pq = (struct Pair *)malloc((n + 1) * sizeof(struct Pair));
    int pqSize = 0;

    pq[pqSize].vertex = src;
    pq[pqSize].distance = 0;
    pqSize++;

    dis[src] = 0;

    double start_time = omp_get_wtime(); // Start measuring execution time

    while (pqSize > 0) {
        int minIdx = 0;
        for (int i = 1; i < pqSize; i++) {
            if (pq[i].distance < pq[minIdx].distance) {
                minIdx = i;
            }
        }
        int u = pq[minIdx].vertex;
        int d = pq[minIdx].distance;

        for (int i = minIdx; i < pqSize - 1; i++) {
            pq[i] = pq[i + 1];
        }
        pqSize--;

        struct Node* temp = array[u].head;
        #pragma omp parallel for schedule(dynamic) shared(paths)
        for (int i = 0; i < k; i++) {
            while (temp != NULL) {
                int v = temp->dest;
                int weight = temp->weight;

                if (d + weight < dis[v]) {
                    dis[v] = d + weight;

                    currentPath = (struct Path*)malloc(sizeof(struct Path));
                    currentPath->cost = dis[v];
                    currentPath->next = NULL;

                    if (paths[0] == NULL) {
                        paths[0] = currentPath;
                    } else {
                        currentPath->next = paths[0];
                        paths[0] = currentPath;
                    }

                    for (int j = 1; j < k; j++) {
                        if (paths[j] == NULL || paths[j]->cost > dis[v]) {
                            break;
                        }
                        struct Path* tempPath = paths[j];
                        paths[j] = currentPath;
                        currentPath = tempPath;
                    }
                }
                temp = temp->next;
            }
        }
    }

    double end_time = omp_get_wtime(); // Stop measuring execution time
    *exec_time = end_time - start_time;

    for (int i = 0; i < k; i++) {
        currentPath = paths[i];
        while (currentPath != NULL) {
            struct Path* newPath = (struct Path*)malloc(sizeof(struct Path));
            newPath->cost = currentPath->cost;
            newPath->next = result;
            result = newPath;
            currentPath = currentPath->next;
        }
    }

    free(dis);
    free(pq);

    return result;
}

int main(int argc, char** argv) {
    int num_procs, my_id;

    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &num_procs);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_id);

    srand(time(NULL) + my_id); // Adjust random seed based on process ID

    int N = 0, M = 0;
    FILE *file = fopen("network_edges.txt", "r");
    if (file == NULL) {
        printf("Error opening the file.\n");
        MPI_Finalize();
        return 1;
    }

    fscanf(file, "%d %d", &N, &M);

    struct List* array = (struct List*)malloc(N * sizeof(struct List));
    for (int i = 0; i < N; i++) {
        array[i].head = NULL;
    }

    for (int i = 0; i < M; i++) {
        int src, dest, weight;
        fscanf(file, "%d %d %d", &src, &dest, &weight);
        addEdge(array, src, dest, weight);
    }

    fclose(file);

    int K = 4;
    struct PairResult {
        int src;
        int dest;
        int proc_num;
        struct Path* paths;
        double exec_time;
    } results[10];

    #pragma omp parallel for num_threads(10)
    for (int i = 0; i < 10; i++) {
        int src = rand() % N;
        int dest = rand() % N;
        double exec_time;
        results[i].src = src;
        results[i].dest = dest;
        results[i].proc_num = my_id; // Assign process number
        results[i].paths = findKShortest(array, N, src, dest, K, &exec_time);
        results[i].exec_time = exec_time;
    }

    // Gather results from all processes
    struct PairResult all_results[10 * num_procs];
    MPI_Gather(results, 10 * sizeof(struct PairResult), MPI_BYTE,
               all_results, 10 * sizeof(struct PairResult), MPI_BYTE,
               0, MPI_COMM_WORLD);

    // Process 0 prints the gathered results
    if (my_id == 0) {
        for (int i = 0; i < 10 * num_procs; i++) {
            if (i < 10) { // Limit the output to only the first 10 pairs
                struct PairResult pair = all_results[i];
                printf("Pair %d: Source = %d, Destination = %d, Process = %d\n", i + 1, pair.src, pair.dest, pair.proc_num);
                printf("Execution Time: %f seconds\n", pair.exec_time);
                struct Path* paths = pair.paths;
                printf("Shortest paths from %d to %d:\n", pair.src, pair.dest);
                int count = 0;
                while (paths != NULL && count < K) {
                    printf("Path %d: Cost = %d\n", count + 1, paths->cost);
                    paths = paths->next;
                    count++;
                }
                printf("\n");
            }
        }
    }

    // Free memory
    for (int i = 0; i < N; i++) {
        struct Node* temp = array[i].head;
        while (temp != NULL) {
            struct Node* prev = temp;
            temp = temp->next;
            free(prev);
        }
    }
    free(array);

    MPI_Finalize();

    return 0;
}
