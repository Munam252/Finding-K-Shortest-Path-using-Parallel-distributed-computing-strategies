#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define INF INT_MAX

struct Node {
    int dest;
    int weight;
    struct Node* next;
};

struct List {
    struct Node* head;
};

struct Path {
    int cost;
    struct Path* next;
};

void addEdge(struct List* array, int src, int dest, int weight) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->dest = dest;
    newNode->weight = weight;
    newNode->next = NULL;

    if (array[src].head == NULL) {
        array[src].head = newNode;
    } else {
        newNode->next = array[src].head;
        array[src].head = newNode;
    }
}

struct Path* findKShortest(struct List* array, int n, int src, int dest, int k) {
    struct Path* paths[k];
    struct Path* result = NULL;
    struct Path* currentPath;

    for (int i = 0; i < k; i++) {
        paths[i] = NULL;
    }

    int *dis = (int *)malloc((n + 1) * sizeof(int));
    for (int i = 0; i <= n; i++) {
        dis[i] = INF;
    }

    struct Pair {
        int vertex;
        int distance;
    };
    struct Pair *pq = (struct Pair *)malloc((n + 1) * sizeof(struct Pair));
    int pqSize = 0;

    pq[pqSize].vertex = src;
    pq[pqSize].distance = 0;
    pqSize++;

    dis[src] = 0;

    while (pqSize > 0) {
        int minIdx = 0;
        for (int i = 1; i < pqSize; i++) {
            if (pq[i].distance < pq[minIdx].distance) {
                minIdx = i;
            }
        }
        int u = pq[minIdx].vertex;
        int d = pq[minIdx].distance;

        for (int i = minIdx; i < pqSize - 1; i++) {
            pq[i] = pq[i + 1];
        }
        pqSize--;

        struct Node* temp = array[u].head;
        while (temp != NULL) {
            int v = temp->dest;
            int weight = temp->weight;

            if (d + weight < dis[v]) {
                dis[v] = d + weight;

                currentPath = (struct Path*)malloc(sizeof(struct Path));
                currentPath->cost = dis[v];
                currentPath->next = NULL;

                if (paths[0] == NULL) {
                    paths[0] = currentPath;
                } else {
                    currentPath->next = paths[0];
                    paths[0] = currentPath;
                }

                for (int i = 1; i < k; i++) {
                    if (paths[i] == NULL || paths[i]->cost > dis[v]) {
                        break;
                    }
                    struct Path* tempPath = paths[i];
                    paths[i] = currentPath;
                    currentPath = tempPath;
                }

                int found = 0;
                for (int i = 0; i < pqSize; i++) {
                    if (pq[i].vertex == v) {
                        pq[i].distance = dis[v];
                        found = 1;
                        break;
                    }
                }
                if (!found) {
                    pq[pqSize].vertex = v;
                    pq[pqSize].distance = dis[v];
                    pqSize++;
                }
            }
            temp = temp->next;
        }
    }

    for (int i = 0; i < k; i++) {
        currentPath = paths[i];
        while (currentPath != NULL) {
            struct Path* newPath = (struct Path*)malloc(sizeof(struct Path));
            newPath->cost = currentPath->cost;
            newPath->next = result;
            result = newPath;
            currentPath = currentPath->next;
        }
    }

    free(dis);
    free(pq);

    return result;
}

void displayRandomPairs(int N, int M, struct List* array, int K) {
    printf("Random Pairs of Vertices:\n");
    srand(time(NULL));
    for (int i = 0; i < 10; i++) {
        int src = rand() % N;
        int dest = rand() % N;
        printf("Pair %d: Source = %d, Destination = %d\n", i + 1, src, dest);
        if (src >= N || dest >= N) {
            printf("Error: Randomly generated source or destination is out of bounds.\n");
            continue;
        }

        clock_t start = clock();
        struct Path* paths = findKShortest(array, N, src, dest, K);
        clock_t end = clock();
        double elapsed_time = ((double)(end - start)) / CLOCKS_PER_SEC;

        printf("Shortest paths from %d to %d:\n", src, dest);
        int count = 0;
        while (paths != NULL && count < K) {
            printf("Path %d: Cost = %d\n", count + 1, paths->cost);
            paths = paths->next;
            count++;
        }

        printf("Execution time: %.6f seconds\n\n", elapsed_time);
    }
}

int main() {
    int N = 0, M = 0;
    FILE *file = fopen("network_edges.txt", "r");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }

    fscanf(file, "%d %d", &N, &M);
    printf("Number of nodes: %d\n", N);
    printf("Number of edges: %d\n", M);

    struct List* array = (struct List*)malloc(N * sizeof(struct List));
    for (int i = 0; i < N; i++) {
        array[i].head = NULL;
    }

    for (int i = 0; i < M; i++) {
        int src, dest, weight;
        fscanf(file, "%d %d %d", &src, &dest, &weight);
        addEdge(array, src, dest, weight);
    }

    fclose(file);

    int K = 4;

    displayRandomPairs(N, M, array, K);

    for (int i = 0; i < N; i++) {
        struct Node* temp = array[i].head;
        while (temp != NULL) {
            struct Node* prev = temp;
            temp = temp->next;
            free(prev);
        }
    }
    free(array);

    return 0;
}

